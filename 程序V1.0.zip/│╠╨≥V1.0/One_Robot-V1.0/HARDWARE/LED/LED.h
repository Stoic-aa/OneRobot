#ifndef  __LED_H
#define  __LED_H
#include "sys.h"
#include "delay.h"
#include "stm32f10x_pwr.h"

#define  LED0  PAout(15)

void LED_Init(void);


#endif

