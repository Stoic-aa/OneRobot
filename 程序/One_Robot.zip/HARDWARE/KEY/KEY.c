#include "key.h"

void KEY_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);//ʹ��PORTC��ʱ�� 

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 
	GPIO_Init(GPIOB, &GPIO_InitStructure);


}


//ע��˺�������Ӧ���ȼ�,KEY0>KEY1>KEY2>KEY3!!

u8 KEY_Scan(u8 mode)
{
	static u8 key_up=1;
	if(mode==1)key_up=1;
    if(key_up&&(KEY0_Stage==0||KEY1_Stage==0||KEY2_Stage==0||KEY3_Stage==0))
	{
		delay_ms(10);
		key_up = 0;
		if(KEY0_Stage==0)return KEY0;
		if(KEY1_Stage==0)return KEY1;
		if(KEY2_Stage==0)return KEY2;
		if(KEY3_Stage==0)return KEY3;
	}else if(KEY0_Stage==1&&KEY1_Stage==1&&KEY2_Stage==1&&KEY3_Stage==1)key_up=1;
	return 0;
	
}
	





