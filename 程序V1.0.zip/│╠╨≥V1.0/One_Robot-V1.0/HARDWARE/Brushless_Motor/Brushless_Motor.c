#include "Brushless_Motor.h"

int VB = 0;
int PWMB = 0;


void BRUSHLESS_MOTOR_Init()
{
	GPIO_InitTypeDef GA;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,  ENABLE);  //ʹ��GPIO����ģ��ʱ��
	
	GA.GPIO_Pin = GPIO_Pin_10;  //����
	GA.GPIO_Mode = GPIO_Mode_Out_PP;  //�������
	GA.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GA);       //��ʼ��GPIO
	DIRB  =0;
}



void BRUSHLESS_ENCODER_TIM1_Init()
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_ICInitTypeDef TIM_ICInitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);//
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);//

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0; //
    TIM_TimeBaseStructure.TIM_Period = 65535;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;//TIM1�߼���ʱ������
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
    TIM_EncoderInterfaceConfig(TIM1, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
    TIM_ICStructInit(&TIM_ICInitStructure);
    TIM_ICInitStructure.TIM_ICFilter = 1;
    TIM_ICInit(TIM1, &TIM_ICInitStructure);
 
    TIM_ClearFlag(TIM1, TIM_FLAG_Update);
    TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);

    TIM_SetCounter(TIM1,0);
    TIM_Cmd(TIM1, ENABLE);
}


void BRUSHLESS_MMOTOR_Set(int dir,int speed)
{
		if(dir==0)   //��ת   
	{
		DIRB = 0;
		PWMB = speed;
		TIM_SetCompare4(TIM3,PWMB);                //����TIM3  CH1ռ�ձ����
	}
	if(dir==1)
	{
		DIRB = 1;
	    PWMB = speed;
		TIM_SetCompare4(TIM3,PWMB);                //����TIM3  CH1ռ�ձ����
	}
	
}




