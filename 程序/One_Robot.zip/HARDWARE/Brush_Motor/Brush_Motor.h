#ifndef _BRUSH_MOTOR_H
#include "sys.h"
#include "delay.h"

#define IN1   PBout(15)
#define IN2   PBout(14)


void BRUSH_MOTOR_Init(void);
void BRUSH_ENCODER_TIM2_Init(void);
void BRUSH_MMOTOR_Set(int dir,int speed);

#endif


