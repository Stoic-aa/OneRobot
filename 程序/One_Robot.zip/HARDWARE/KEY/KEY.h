#ifndef _KEY_H
#include "sys.h"
#include "delay.h"

#define  KEY0_Stage  PBin(3)
#define  KEY1_Stage  PBin(4)
#define  KEY2_Stage  PBin(5)
#define  KEY3_Stage  PBin(6)

#define  KEY0  1
#define  KEY1  2
#define  KEY2  3
#define  KEY3  4

void KEY_Init(void);
u8 KEY_Scan(u8 mode);


#endif

