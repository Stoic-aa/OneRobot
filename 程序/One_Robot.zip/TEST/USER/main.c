#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "oled.h"
#include "string.h"
#include "stm32f10x_pwr.h"
#include "encoder.h"
#include "motor.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h" 
#include "mpu6050.h"

float pitch,roll,yaw; 		//ŷ����

int main(void)
 {	
	    u8 key;	
        u8 key1;	
        u8 key2;	 
		delay_init();	    	 //��ʱ������ʼ��	
      
       // NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);   //����	 
		OLED_Init();			//��ʼ��OLED  
	    OLED_Clear(); 
		OLED_ShowCHinese(0,0,0);//
		OLED_ShowCHinese(20,0,1);//
		OLED_ShowCHinese(40,0,2);//	
		OLED_ShowCHinese(60,0,3);//
	 
	    OLED_ShowString(0,3,"MPU_init:",12);
	 
	    OLED_ShowString(0,5,"Pith:",12);
		OLED_ShowString(0,6,"Roll:",12);
		OLED_ShowString(0,7,"Yaw:",12);
	   
	 
	   KEY_Init();
	 

	    uart_init(115200);
	    MPU_Init();					//��ʼ��MPU6050
		 while(mpu_dmp_init())
			{
				
				OLED_ShowString(70,3,"ERROR",12);
				delay_ms(200);
			}  
			OLED_ShowString(70,3,"Success",12);
        TIM3_PWM_Init(7199,0);
	    ENCODER_A_Init();			
	    MOTOR_CONTORL_GPIO_Init();
	    TIME4_Init();
		TIM_SetCompare4(TIM3,7000);
	 
				
	 	 
	 
	   while(1)
	   {
		 key  = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5);
		 key1 = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6); 
         key2 = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7); 		   
		if(key == 0)
		{
			
		     delay_ms(10);
			if(key == 0)
			{
				PAout(6) = 0;
				PBout(0) = 1;
				TIM_SetCompare2(TIM3,6000);
				TIM_SetCompare4(TIM3,4000);
						
			}
		
		}
		
		if(key1 == 0)
		{
			
		     delay_ms(10);
			if(key1 == 0)
			{
				PAout(6) = 1;
				PBout(0) = 0;
				TIM_SetCompare2(TIM3,2000);
				TIM_SetCompare4(TIM3,4000);
				
				
			}
		
		}
		
		if(key2 == 0)
		{
			
		     delay_ms(10);
			if(key2 == 0)
			{
				PAout(6) = 1;
				PBout(0) = 0;
				TIM_SetCompare2(TIM3,7100);
				TIM_SetCompare4(TIM3,7100);
				
				
			}

		
		}
		
		
					
			OLED_ShowNum(20,5,pitch,3,12);
			OLED_ShowNum(20,6,roll,3,12);
			OLED_ShowNum(20,7,yaw,3,12);
		   
		

       }
 }





