#ifndef _ENCODER_H
#define _ENCODER_H
#include "sys.h"
#define EncA1  PAin(1)



#define EncB1  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)
#define EncB2  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11)

void TIME4_Init();
void ENCODER_A_Init(void);
int DIR_ENCODER_A_Init(void);


void ENCODER_B_Init(void);

void DoEncoderA(void);
void DoEncoderB(void);

#endif