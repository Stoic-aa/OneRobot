#ifndef _MOTOR_H
#define _MOTOR_H
#include "sys.h"

#define  IN1  PBout(2)
#define  IN2  PBout(3)
#define  IN3  PBout(4)
#define  IN4  PBout(5)


void MOTORA_PWM3_Init(u16 arr,u16 psc);
void MOTOR_CONTORL_GPIO_Init(void);
void TIM1_Init(u16 arr,u16 psc);  //��ʱ��1��ʼ��
void TIM3_PWM_Init(u16 arr,u16 psc);



#endif