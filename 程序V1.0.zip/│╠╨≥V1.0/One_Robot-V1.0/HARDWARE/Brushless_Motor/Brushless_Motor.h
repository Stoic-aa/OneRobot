#ifndef _BRUSHLESS_MOTOR_H
#include "sys.h"
#include "delay.h"
#define DIRB   PAout(10)


void BRUSHLESS_MOTOR_Init(void);
void BRUSHLESS_ENCODER_TIM1_Init(void);
void BRUSHLESS_MMOTOR_Set(int dir,int speed);
void BRUSHLESS_PWM_TIM1_Init(void);




#endif

