#ifndef __USMART_H
#define __USMART_H	  		  
#include "usmart.h"
#include "usart.h"
#include "sys.h"
#define  report  1
void usart1_send_char(u8 c);
void usart1_niming_report(int A,int B,int C,int D,u8 len);
void mpu6050_send_data(short aacx,short aacy,short aacz,short gyrox,short gyroy,short gyroz);
void usart1_report_imu(short aacx,short aacy,short aacz,short gyrox,short gyroy,short gyroz,short roll,short pitch,short yaw);
void usart2_niming_report(int A,int B,int C,int D,int E,u8 len);


#endif






























