#ifndef _TIMER_H
#include "sys.h"
#include "delay.h"
#include "Brush_Motor.h"
#include "usart.h"

void TIM4_Init(u16 arr,u16 psc);//7199,149  Ϊ15ms
void TIM3_Init(u16 arr,u16 psr);
int Read_Encoder(u8 TIMX);

#endif


