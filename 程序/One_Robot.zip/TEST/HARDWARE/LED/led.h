#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define     LED0                           PCout(13) //���ݶ˿�PC13
#define     GPIOC13_IO_IN()               {GPIOC->CRH &= 0xFF0FFFFF;GPIOC->CRH|= 0xFF8FFFFF;}
#define     GPIOC13_IO_OUT()              {GPIOC->CRH &= 0xFF0FFFFF;GPIOC->CRH|= 0xFF3FFFFF;}
#define     GPIOC13_OUT                    PCout(13) //���ݶ˿�PC13
#define     GPIOC13_IN                     PCin(13)   //���ݶ˿�PC13 

void LED_Init(void);//��ʼ��

		 				    
#endif
